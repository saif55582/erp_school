<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function requiredStar() {
	return "<span class='text-danger'>*</span>";
}


?>