<script>

	$('#form_add_marks').bind('submit', function(e) {
		e.preventDefault();
		var ei = $(this).find('#exam').val();
		var ci = $(this).find('#class').val();
		var si = $(this).find('#sec').val();
		var subi = $(this).find('#sub').val();
		var data = 'y='+ci+'&z='+si+'&s='+subi;
		$.ajax({
			type: 'POST',
			url: '<?=base_url()?>marks/gStAddMarks',
			data: data,
			success: function(data) {
				$('#tbody').html(data);
			}
		}).fail(function(errObj, status, err){
			demo.showNotification('top','center', 'error',4, err);
		});
	});

	$('#set_marks').bind('click', function() {
		var ei = $('#form_add_marks').find('#exam').val();
		var ci = $('#form_add_marks').find('#class').val();
		var si = $('#form_add_marks').find('#sec').val();
		var subi = $('#form_add_marks').find('#sub').val();
		var m = [];
		var st = [];
		$('#tbody tr').each(function() {
			
			var sm = $(this).find('#marks_obtained').val();
			var s = $(this).find('#student').val()
			m.push(sm);
			st.push(s);
		});
		var data = 'a='+ei+'&b='+ci+'&c='+si+'&d='+subi+'&e='+st+'&f='+m;
		$.ajax({
			type: 'post',
			url: '<?=base_url()?>/marks/aM',
			data: data,
			success: function(data) {
				console.log(data);
			}
		}).fail(function(errObj, status, err) {
			demo.showNotification('top','center', 'error',4, err);
		});
		
	});

</script>