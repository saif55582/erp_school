<div  class="content">

    <div class="container-fluid">

        <div class="row">

            <div class="col-sm-12">

                <div class="card">

                    <div class="card-header card-header-icon" data-background-color="rose">

                        <i class="material-icons">assignment</i>

                    </div>

                    <div class="card-content">

						<h4 class="card-title my-title">Fine Category</h4>

                        <ul class="nav nav-pills nav-pills-rose">
                            <li class="active">
                                <a href="#pill1" data-toggle="tab">Add Fine</a>
                            </li>
                            <li>
                                <a href="#pill2" data-toggle="tab">Fine List</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="pill1">
                                
                            </div>
                            <div class="tab-pane" id="pill2">
                              

                            </div>
                        </div>

		            </div>

		        </div>

		    </div>
		    
		</div>

	</div>

</div>

