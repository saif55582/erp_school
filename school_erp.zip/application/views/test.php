<?php

// foreach ($teacher as $t) {
// 	echo $t['name'];
// 	# code...
// }
print_r($teacher);
echo 'test.php';

?>