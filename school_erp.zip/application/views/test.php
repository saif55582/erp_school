<?php

//echo $title.','.$subview.','.$script.','.$active.','.$subactive;
?>