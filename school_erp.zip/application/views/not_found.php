<div class="content">
    <div class="container-fluid">
        <div class="row">
            <center>
                <img style="width:700px" src="<?=base_url()?>/main_asset/assets/img/404.jpg" alt="" class="img img-responsive">
                <h2><small>The page you have requested is moved or deleted or you are not authorised to access the page. </small></h2>
            </center>
        </div>
    </div>
</div>