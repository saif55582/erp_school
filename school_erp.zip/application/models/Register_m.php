<?php

defined('BASEPATH') OR die('No Direct Scripting Allowed');

class Register_m extends MY_Model {

	
}