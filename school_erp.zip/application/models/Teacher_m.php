<?php
defined('BASEPATH') or exit('No direct scripting allowed');

class teacher_m extends MY_Model {

	protected $_table_name = 'teacher';
	protected $_primary_key = 'teacherID';
	protected $_primary_filter = 'intval';
	protected $_order_by = 'name asc';

	function __constuct() {
		parent::__constuct();
	}

	function insert_teacher($array) {
		$id = parent::insert($array);
		return true;
	}

	function get_order_by_teacher($array=NULL) {
		$query = parent::get_order_by($array);
		return $query;
	}

	function get_by_teacher_name($array=NULL) {
		$query = parent::get_single($array);
		return $query;
	}

	function get_teacher_by_id($id=NULL,$single=NULL) {
		$query = parent::get($id,$single);
		return $query;
	}

	function get_autocomplete($q) {
	    $this->db->select('*');
	    $h = "name LIKE '%".$q."%' or teacherID LIKE '%".$q."%' ";
	    $this->db->where($h);
	    $query = $this->db->get('teacher');
	    if($query->num_rows() > 0){
	      foreach ($query->result_array() as $row){
	        $row_set[] = $row['name'].'=>'.$row['teacherID']; //build an array
	      }
	      echo json_encode($row_set); //format the array into json data
	    }
	    else {
	    	echo json_encode(array('Teacher not found'));
	    }
	 }





}