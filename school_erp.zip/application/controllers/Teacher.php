<?php 

defined('BASEPATH') or exit('No direct scripting allowed');

class Teacher extends MY_Controller {

	function __construct() {

		parent::__construct();
		if($this->mylibrary->isLoggedIn() == FALSE) {
			redirect('signin');
		}
	}

	function get_teacher() {
		$query = parent::get();
		return $query;
	}

	function get_autocomplete() {
	    if (isset($_GET['term'])) {
	    	$q = ($_GET['term']);
	      	$this->teacher_m->get_autocomplete($q);
	    }
    }

}