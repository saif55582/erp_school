<?php
defined('BASEPATH') or exit('No direct scripting allowed');

class Section extends MY_Controller {

	function __construct() {

		parent::__construct();
		if($this->mylibrary->isLoggedIn() == FALSE) {
			redirect('signin');
		}
	}

	function index() {
		$this->data['classes'] = $this->classes_m->get_order_by_classes();
		$this->data['sections'] = $this->section_m->get_section();
		$this->data['teachers'] = $this->teacher_m->get_order_by_teacher();
		$this->data['title'] = 'Section';
		$this->data['subview'] = 'academics/section';
		$this->data['script'] = 'academics/section_js';
		$this->data['active'] = 'academics';
		$this->data['subactive'] = 'section';
		$this->load->view('main_layout', $this->data);
	}

	function rules_insert() {

		$rules = array(
			array(
				'field'=>'section_name',
				'label'=>'Section Name',
				'rules'=>'trim|required|xss_clean|alpha_numeric'
			),
			array(
				'field'=>'classesID',
				'label'=>'Class',
				'rules'=>'trim|required|xss_clean'
			),
			array(
				'field'=>'teacherID',
				'label'=>'Teacher',
				'rules'=>'trim|required|xss_clean'
			),
			array(
				'field'=>'max_student',
				'label'=>'Max Students',
				'rules'=>'trim|xss_clean|required|numeric'
			),
			array(
				'field'=>'note',
				'label'=>'Note',
				'rules'=>'trim|xss_clean|alpha_numeric_spaces'
			),
		);
		return $rules;
	}

	function getSection() {
		$classesID = $this->input->post('classesID');
		$index = 1;
		$result = '';
		$sections = $this->section_m->get_section_by_class(array('classesID'=>$classesID));
		if(!$sections)
			echo 'nosection';
		else {
			foreach ($sections as $section) :
		$result .= "    
				<tr id='".$section->sectionID."'>
				<td>".$index++."</td>
				<td>".strtoupper($section->section_name)."</td>
				<td>";
				    $teacher = $this->teacher_m->get_teacher_by_id($section->teacherID);
				    if(($teacher->name)){
				        $result .= strtoupper($teacher->name);
				    }
				    else
				        $result .= '----';
	$result .= "</td>
				<td>".$section->max_student."</td>
				<td>".$section->note."</td>
				<td class='text-center'>
				<a href='#' onclick='getEdit(".$section->sectionID.");' data-toggle='modal' data-target='#supportModal' class='btn mybtn btn-info btn-icon'><i class='material-icons'>edit</i></a>
				<a href='#' id='". $section->sectionID."' onclick='del(this.id)' class='btn mybtn btn-danger btn-icon remove'><i class='material-icons'>close</i></a>
				</td>
				</tr>";
		endforeach;

				echo $result;
		}
		
	}

	function insertSection() {

		$rules = $this->rules_insert();
		//$this->form_validation->set_rules($rules);
		$this->data['form_validation'] = '';
		$this->form_validation->set_rules($rules);
		if($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('reply_insert','error');
			$this->index();
			//redirect('classes');
		}
		else {
			$array = array();
			for($i=0;$i<count($rules);$i++) {
				if($this->input->post($rules[$i]['field']) == FALSE) {
					$array[[$i]['field']] == 0;
				}
				else {
						$array[$rules[$i]['field']] = $this->input->post($rules[$i]['field']);
				}
			}
			
			$classesID =  $array['classesID'];
			$this->session->set_flashdata('classesID',$classesID);
			$this->section_m->insertSection($array);
			$this->session->set_flashdata('reply_insert','success');
			redirect('section');
		}
	}

	function deleteSection() {
		$sectionID = $this->input->post('id');
		$this->section_m->deleteSection($sectionID);
	}

	function editForm() {
		$sessionID = $this->input->post('sectionID');
		$section = $this->section_m->get_section($sessionID,TRUE);
		$result = "";
		$result .= "
		<form method='post' class='classform form-horizontal' action='".base_url('section/editSection')."'>
            <div class='form-group label-floating'>
                <label class='label-on-left'>Section Name: <span class='text-danger'>*</span></label>
                <input type='text' value='".$section->section_name."' class='form-control up_case' name='section_name' id='section_name'>
                <h7 class='text-danger'><?= form_error('section_name')?></h7>
            </div>

            <div onclick='setFocus();' class='form-group label-floating'>
                <label class='control-labe'>Class: <span class='text-danger'>*</span></label>
                <select name='classesID'  data-live-search='true' class='selectpicker' data-style='select-with-transition' title=' '>";
                $classes = $this->classes_m->get_order_by_classes();
                    foreach ($classes as $class) {
                    	if($class->classesID == $section->classesID) {
                        	$result .= "<option selected value='".$class->classesID."'>".strtoupper($class->class_name)."</option>";
                        }
                        else {
                        	$result .= "<option value='".$class->classesID."'>".strtoupper($class->class_name)."</option>";
                        }	
                    }
    $result .="</select>
                <h7 class='text-danger'><?= form_error('classesID')?></h7>
            </div>    

            <div class='form-group label-floating'>
                <label class='control-labe'>Teacher: <span class='text-danger'>*</span></label>
                <select name='teacherID'  data-live-search='true' class='selectpicker' data-style='select-with-transition' title=' '>";
                	$teachers = $this->teacher_m->get_order_by_teacher();
                    foreach ($teachers as $teacher) {
                    	if($teacher->teacherID == $section->teacherID) {
	                        $result .="<option selected value='".$teacher->teacherID."'>".strtoupper($teacher->name)."</option>";
	                    }
	                    else {
	                    	$result .="<option value='".$teacher->teacherID."'>".strtoupper($teacher->name)."</option>";
	                    }
                    }
               $result .= "</select>
                <h7 class='text-danger'><?= form_error('teacherID')?></h7>
            </div>     

            <div class='form-group label-floating'>
                <label class='control-labe'>Max Students: <span class='text-danger'>*</span></label>
                <input value='".$section->max_student."' type='text' class='form-control up_case' name='max_student'>
                <h7 class='text-danger'><?= form_error('max_student')?></h7>
            </div>
            <div class='form-group label-floating'>
                <label class='control-labe'>Note: </label>
                <input value='".$section->note."' type='text' class='form-control up_case' name='note'>
                <h7 class='text-danger'><?= form_error('note')?></h7>
            </div>
            <button type='submit' class='btn btn-success btn-sm'>Add</button>
        </form>";
        echo $result;
	}
}