<?php 

defined('BASEPATH') or exit('No direct scripting allowed');

class Classes extends MY_Controller {

	function __construct() {

		parent::__construct();
		if($this->mylibrary->isLoggedIn() == FALSE) {
			
			redirect('signin');
		}
	}

	function rules() {

		$rules = array(
			array(
				'field' =>'class_name',
				'label' =>'Class Name',
				'rules' =>'trim|required|xss_clean|max_length[40]|alpha_numeric|callback_check_unique[class_name]'
			),
			array(
				'field' =>'teacherID',
				'label' =>'Class Incharge',
				'rules' =>'trim|xss_clean|max_length[50]'
			),
			array(
				'field' =>'max_student',
				'label' =>'Max Students',
				'rules' =>'trim|required|xss_clean|max_length[20]|integer'
			),
			array(
				'field' =>'note',
				'label' =>'Note',
				'rules' =>'trim|xss_clean|max_length[150]|alpha_numeric_spaces'
			)
		);

		return $rules;
	}

	function check_unique($param,$column) {
		if($param === '0') {
			$this->form_validation->set_message('check_unique','The %s field is required');
			return false;
		}
		else {
			$row = $this->classes_m->get_single(array($column => $param));
			if($row) {
				$this->form_validation->set_message('check_unique', '%s already exists.');
				return false;
			}
			else
				return true;
		}
	}


	function rulesEdit() {

		$rules = array(
			array(
				'field' =>'class_name',
				'label' =>'Class Name',
				'rules' =>'trim|required|xss_clean|max_length[40]|alpha_numeric|callback_check_unique_with_id[class_name]'
			),
			array(
				'field' =>'teacherID',
				'label' =>'Class Incharge',
				'rules' =>'trim|xss_clean|max_length[50]'
			),
			array(
				'field' =>'max_student',
				'label' =>'Max Students',
				'rules' =>'trim|required|xss_clean|max_length[20]|integer'
			),
			array(
				'field' =>'note',
				'label' =>'Note',
				'rules' =>'trim|xss_clean|max_length[150]|alpha_numeric_spaces'
			)
		);

		return $rules;
	}

	function check_unique_with_id($param,$column) {
		$classesID =  $this->input->post('perm');
		if($param === '0') {
			$this->form_validation->set_message('check_unique_with_id','The %s field is required');
			return false;
		}
		else {
			$h = "class_name = '".$param."' and classesID != ".$classesID;

			$row = $this->classes_m->get_single($h);
			if($row) {
				$this->form_validation->set_message('check_unique_with_id', '%s already exists.');
				return false;
			}
			else {
				return true;
			}
		}
	}

	function index() {

		$this->data['classes'] = $this->classes_m->get_order_by_classes();
		$this->data['teachers'] = $this->teacher_m->get_teacher_by_id();
		$this->data['title'] = 'Class';
		$this->data['subview'] = 'academics/class';
		$this->data['script'] = 'academics/class_js';
		$this->data['active'] = 'academics';
		$this->data['subactive'] = 'class';
		$this->load->view('main_layout', $this->data);
	}

	function addClass() {
		$rules = $this->rules();
		$this->data['form_validation'] = '';
		$this->form_validation->set_rules($rules);
		if($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('reply','error');
			$this->index();
			//redirect('classes');
		}
		else {
			$array = array();
			for($i=0;$i<count($rules);$i++) {
				if($this->input->post($rules[$i]['field']) == FALSE) {
					$array[[$i]['field']] == 0;
				}
				else {
						$array[$rules[$i]['field']] = $this->input->post($rules[$i]['field']);
				}
			}
			//print_r($array);
			$this->classes_m->insert_class($array);
			$this->session->set_flashdata('reply','success');
			redirect('classes');
		}
	}

	function sendEditForm() {
		$classesID = $this->input->post('id');
		$row = $this->classes_m->get_class_by_id($classesID,true);
		$result = '';
		$result .= "<form method='post' class='classform2' action='".base_url('classes/editClass')."'>
					<input type='hidden' value='".$row->classesID."' name='perm'>
                    <div class='form-group label-floating'>
                        <label class='control-labe'>Class Name: <span class='text-danger'>*</span></label>
                        <input type='text' class='form-control up_case' name='class_name' id='class_name' value='".$row->class_name."'>
                        <h7 class='text-danger'><?= form_error('class_name')?></h7>
                        <h7 class='text-danger' id='myerror'></h7>
                    </div>

                    <div class='form-group label-floating'>
                        <label class='control-labe'>Class Incharge: <span class='text-danger'>*</span></label>
                        <select name='teacherID'  data-live-search='true' class='selectpicker' data-style='select-with-transition' title=' '>";
                        	$teachers = $this->teacher_m->get_teacher_by_id();
                            foreach ($teachers as $teacher) {
                            	if($teacher->teacherID == $row->teacherID) {
                            		$result .= "<option selected value='".$teacher->teacherID."'>".$teacher->name."</option>";
                            	}
                            	else {
                            		$result .= "<option value='".$teacher->teacherID."'>".$teacher->name."</option>";
                            	}
                        		
                            }
             $result .= "</select>
                        <h7 class='text-danger'><?= form_error('teacherID')?></h7>
                    </div>                       
                    <div class='form-group label-floating'>
                        <label class='control-labe'>Max Students: <span class='text-danger'>*</span></label>
                        <input type='text' class='form-control up_case' name='max_student' value='".$row->max_student."'>
                        <h7 class='text-danger'><?= form_error('max_student')?></h7>
                    </div>
                    <div class='form-group label-floating'>
                        <label class='control-labe'>Note: </label>
                        <input type='text' class='form-control up_case' name='note' value='".$row->note."'>
                        <h7 class='text-danger'><?= form_error('note')?></h7>
                    </div>
                    <button id='sub' type='submit' class='btn btn-success btn-sm'>Update</button>
                </form>";
            echo $result;
	}

	function deleteClass() {
		$id = $this->input->post('id');
		$this->classes_m->delete_class($id);
	}

	function editClass() {
		$classesID = $this->input->post('perm');
		$rules = $this->rulesEdit();
		$this->data['form_validation'] = '';
		$this->form_validation->set_rules($rules);
		if($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('reply_edit','error');
			$this->session->set_flashdata('open_modal',$this->input->post('perm'));
			$this->index();
			//redirect('classes');
		}
		else {
			$array = array();
			for($i=0;$i<count($rules);$i++) {
				if($this->input->post($rules[$i]['field']) == FALSE) {
					$array[[$i]['field']] == 0;
				}
				else {
					// if($rules[$i]['field'] == 'teacherID') {
					// 	$teacher = $this->input->post($rules[$i]['field']);
					// 	$t_explode = explode('=>',$teacher);
					// 	$array[$rules[$i]['field']] = end($t_explode);
					// }
					//else
						$array[$rules[$i]['field']] = $this->input->post($rules[$i]['field']);
				}
			}
			$this->classes_m->update_class($array,$classesID);
			$this->session->set_flashdata('reply_edit','success');
			redirect('classes');
		}

	}

}

