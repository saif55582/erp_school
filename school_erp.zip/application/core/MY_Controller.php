<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

	public $data = array();

	public function __construct() {

		parent::__construct();
		$this->load->model('institute_details_m');
		$this->load->model('signin_m');
		$this->load->model('setting_m');
		$this->load->model('classes_m');
		$this->load->model('teacher_m');
		$this->load->model('section_m');

		$result  = $this->institute_details_m->get();
		$institute_details = array();
		foreach($result as $row):
			$institute_details[$row->feild_name] = $row->feild_value;
		endforeach;
		$this->data['institute_details'] = $institute_details;
		$this->data['subactive'] = '';
		
	}

}

